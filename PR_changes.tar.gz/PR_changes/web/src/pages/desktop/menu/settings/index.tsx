import { useEffect, useState } from 'react';
import { Badge, Modal, Tooltip } from 'antd';
import clsx from 'clsx';
import { useSetAtom } from 'jotai';
import {
  BadgeInfoIcon,
  CircleArrowUpIcon,
  PaletteIcon,
  SettingsIcon,
  ShieldIcon,
  SmartphoneIcon,
  UserRoundIcon
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import semver from 'semver';

import * as api from '@/api/application.ts';
import * as authApi from '@/api/auth.ts';
import * as ls from '@/lib/localstorage.ts';
import { isKeyboardEnableAtom } from '@/jotai/keyboard.ts';
import { submenuOpenCountAtom } from '@/jotai/settings.ts';
import { Tailscale as TailscaleIcon } from '@/components/icons/tailscale';
import { ScrollArea } from '@/components/ui/scroll-area';

import { useRole } from '@/hooks/useRole.ts';
import { About } from './about';
import { Account } from './account';
import { Appearance } from './appearance';
import { Device } from './device';
import { Tailscale } from './tailscale';
import { Update } from './update';
import { Users } from './users';

export const Settings = () => {
  const { t } = useTranslation();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [currentTab, setCurrentTab] = useState('about');
  const [isUpdateAvailable, setIsUpdateAvailable] = useState(false);
  const setIsKeyboardEnable = useSetAtom(isKeyboardEnableAtom);
  const setSubmenuOpenCount = useSetAtom(submenuOpenCountAtom);
  const { isAdmin, isOperator } = useRole();

  // Tabs basierend auf Rolle
  const allTabs = [
    { id: 'about',      roles: ['admin','operator','viewer'], icon: <BadgeInfoIcon size={16} />,   component: <About /> },
    { id: 'appearance', roles: ['admin','operator','viewer'], icon: <PaletteIcon size={16} />,     component: <Appearance /> },
    { id: 'device',     roles: ['admin'],                     icon: <SmartphoneIcon size={16} />,  component: <Device /> },
    { id: 'tailscale',  roles: ['admin'],                     icon: <TailscaleIcon />,             component: <Tailscale setIsLocked={setIsLocked} /> },
    { id: 'update',     roles: ['admin'],                     icon: <CircleArrowUpIcon size={16} />, component: <Update setIsLocked={setIsLocked} /> },
    { id: 'account',    roles: ['admin','operator','viewer'], icon: <UserRoundIcon size={18} />,   component: <Account /> },
    { id: 'users',      roles: ['admin'],                     icon: <ShieldIcon size={16} />,      component: <Users /> },
  ];

  const currentRole = isAdmin ? 'admin' : isOperator ? 'operator' : 'viewer';
  const tabs = allTabs.filter(t => t.roles.includes(currentRole));

  useEffect(() => {
    const skip = ls.getSkipUpdate();
    if (!skip) checkForUpdates();


  }, []);

  function checkForUpdates() {
    api.getVersion().then((rsp: any) => {
      if (rsp.code !== 0) return;
      if (!rsp.data?.current || !rsp.data?.latest) return;
      if (semver.gt(rsp.data.latest, rsp.data.current)) {
        setIsUpdateAvailable(true);
      }
    });
  }

  function changeTab(tab: string) {
    if (isLocked) return;
    setCurrentTab(tab);
    if (isUpdateAvailable && tab === 'update') {
      setIsUpdateAvailable(false);
      ls.setSkipUpdate(true);
    }
  }

  function openModal() {
    setIsModalOpen(true);
    setIsKeyboardEnable(false);
    setSubmenuOpenCount((count) => count + 1);
  }

  function closeModal() {
    if (isLocked) return;
    setIsKeyboardEnable(true);
    setIsModalOpen(false);
    setCurrentTab('about');
    setSubmenuOpenCount((count) => Math.max(0, count - 1));
  }

  return (
    <>
      <Tooltip title={t('settings.title')} placement="bottom" mouseEnterDelay={0.6}>
        <div
          className="flex h-[30px] w-[30px] cursor-pointer items-center justify-center rounded hover:bg-neutral-700/80"
          onClick={openModal}
        >
          <Badge dot={isUpdateAvailable} color="blue" offset={[0, 2]}>
            <div className="pt-[3px] text-neutral-300 hover:text-white">
              <SettingsIcon size={18} />
            </div>
          </Badge>
        </div>
      </Tooltip>

      <Modal
        open={isModalOpen}
        width={'80%'}
        centered={true}
        footer={null}
        destroyOnHidden={true}
        onCancel={closeModal}
        style={{ maxWidth: '1080px' }}
        styles={{ content: { padding: 0 } }}
      >
        <div className="flex h-[80vh] max-h-[700px] rounded-lg outline outline-1 outline-neutral-700">
          <div className="flex h-full max-w-[260px] flex-col space-y-0.5 rounded-l-lg bg-neutral-800/90 px-1 sm:w-1/5 md:w-1/4 md:px-2">
            <div className="hidden px-3 pt-10 text-xl sm:block">{t('settings.title')}</div>
            <div className="h-10 sm:h-5" />
            {tabs.map((tab) => (
              <div
                key={tab.id}
                className={clsx(
                  'flex cursor-pointer select-none items-center space-x-2 rounded-lg p-2 sm:px-3',
                  currentTab === tab.id ? 'bg-neutral-700/50' : 'hover:bg-neutral-700/50'
                )}
                onClick={() => changeTab(tab.id)}
              >
                <div className="h-[16px] w-[16px]">{tab.icon}</div>

                {isUpdateAvailable && tab.id === 'update' ? (
                  <Badge dot color="blue" offset={[6, 3]}>
                    <span className="hidden truncate text-sm sm:block">
                      {t(`settings.${tab.id}.title`)}
                    </span>
                  </Badge>
                ) : (
                  <span className="hidden truncate text-sm sm:block">
                    {t(`settings.${tab.id}.title`)}
                  </span>
                )}
              </div>
            ))}
          </div>

          <ScrollArea className="h-full w-full rounded-r-lg bg-neutral-900/50 px-3">
            <div className="flex h-full w-full justify-center">
              <div className="w-full max-w-[600px] pb-10 pt-14">
                <>{tabs.find((tab) => tab.id === currentTab)?.component}</>
              </div>
            </div>
          </ScrollArea>
        </div>
      </Modal>
    </>
  );
};
